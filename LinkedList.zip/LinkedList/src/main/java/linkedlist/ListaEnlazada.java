package linkedlist;

import java.util.Iterator;
import java.util.Spliterator;
import java.util.function.Consumer;

public class ListaEnlazada<T> implements IList<T>, Iterable<T> {

    protected NodoDoble<T> inicio;
    protected NodoDoble<T> actual;
    protected int nElementos;

    private class NodoDoble<T> {

        private T dato;
        private NodoDoble<T> sig;
        private NodoDoble<T> ant;

        public NodoDoble(T dato) {
            this.dato = dato;
            this.sig = null;
            this.ant = null;
        }
    }

    public ListaEnlazada() {
        inicio = null;
        actual = null;
        nElementos = 0;
    }

    @Override
    public void append(T elemento) throws ListException {
        NodoDoble<T> nodoNuevo = new NodoDoble<>(elemento);

        if (inicio == null) {
            inicio = nodoNuevo;
            inicio.sig = inicio;
            inicio.ant = inicio;
            actual = inicio;
        } else {
            NodoDoble<T> cola = inicio.ant;
            cola.sig = nodoNuevo;
            nodoNuevo.ant = cola;
            nodoNuevo.sig = inicio;
            inicio.ant = nodoNuevo;
        }

        nElementos++;
    }

    @Override
    public void insert(T elemento, int index) throws ListException {
        if (index < 0 || index > nElementos) {
            throw new ListException("Indice fuera de rango");
        }

        if (index == nElementos) {
            append(elemento);
            return;
        }

        NodoDoble<T> nodoNuevo = new NodoDoble<>(elemento);

        if (index == 0) {
            if (inicio == null) {
                inicio = nodoNuevo;
                inicio.sig = inicio;
                inicio.ant = inicio;
                actual = inicio;
            } else {
                NodoDoble<T> cola = inicio.ant;
                nodoNuevo.sig = inicio;
                nodoNuevo.ant = cola;
                inicio.ant = nodoNuevo;
                cola.sig = nodoNuevo;
                inicio = nodoNuevo;
            }
        } else {
            NodoDoble<T> aux = inicio;
            for (int i = 0; i < index; i++) {
                aux = aux.sig;
            }

            NodoDoble<T> anterior = aux.ant;
            anterior.sig = nodoNuevo;
            nodoNuevo.ant = anterior;
            nodoNuevo.sig = aux;
            aux.ant = nodoNuevo;
        }

        nElementos++;
    }

    @Override
    public T remove(int index) throws ListException {
        if (index < 0 || index >= nElementos) {
            throw new ListException("Indice fuera de rango");
        }

        NodoDoble<T> eliminado;

        if (nElementos == 1) {
            eliminado = inicio;
            inicio = null;
            actual = null;
        } else {
            NodoDoble<T> aux = inicio;
            for (int i = 0; i < index; i++) {
                aux = aux.sig;
            }

            eliminado = aux;

            if (aux == inicio) {
                inicio = inicio.sig;
            }

            if (aux == actual) {
                actual = actual.sig;
            }

            aux.ant.sig = aux.sig;
            aux.sig.ant = aux.ant;
        }

        nElementos--;
        return eliminado.dato;
    }

    @Override
    public boolean removeObj(T elemento) throws ListException {
        int indice = indexOf(elemento);

        if (indice == -1) {
            return false;
        }

        remove(indice);
        return true;
    }

    @Override
    public int indexOf(T elemento) {
        if (empty()) {
            return -1;
        }

        NodoDoble<T> nodo = inicio;
        for (int i = 0; i < nElementos; i++) {
            if (elemento == null) {
                if (nodo.dato == null) {
                    return i;
                }
            } else if (elemento.equals(nodo.dato)) {
                return i;
            }
            nodo = nodo.sig;
        }

        return -1;
    }

    @Override
    public T get(int index) throws ListException {
        if (index < 0 || index >= nElementos) {
            throw new ListException("Indice fuera de rango");
        }

        NodoDoble<T> nodo = inicio;
        for (int i = 0; i < index; i++) {
            nodo = nodo.sig;
        }

        return nodo.dato;
    }

    @Override
    public void set(T elemento, int index) throws ListException {
        if (index < 0 || index >= nElementos) {
            throw new ListException("Indice fuera de rango");
        }

        NodoDoble<T> nodo = inicio;
        for (int i = 0; i < index; i++) {
            nodo = nodo.sig;
        }

        nodo.dato = elemento;
    }

    @Override
    public void clear() {
        inicio = null;
        actual = null;
        nElementos = 0;
    }

    @Override
    public boolean empty() {
        return nElementos == 0;
    }

    @Override
    public int size() {
        return nElementos;
    }

    @Override
    public void irInicio() {
        actual = inicio;
    }

    @Override
    public void irFinal() {
        if (inicio != null) {
            actual = inicio.ant;
        }
    }

    @Override
    public void previous() {
        if (actual != null) {
            actual = actual.ant;
        }
    }

    @Override
    public void next() {
        if (actual != null) {
            actual = actual.sig;
        }
    }

    @Override
    public T getActual() {
        if (actual == null) {
            return null;
        }
        return actual.dato;
    }

    @Override
    public Iterator<T> Iterator() {
        return iterator();
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {

            private NodoDoble<T> curr = inicio;
            private int cont = 0;

            @Override
            public boolean hasNext() {
                return cont < nElementos;
            }

            @Override
            public T next() {
                T dato = curr.dato;
                curr = curr.sig;
                cont++;
                return dato;
            }
        };
    }

    @Override
    public void forEach(Consumer<? super T> action) {
        Iterable.super.forEach(action);
    }

    @Override
    public Spliterator<T> spliterator() {
        return Iterable.super.spliterator();
    }
}